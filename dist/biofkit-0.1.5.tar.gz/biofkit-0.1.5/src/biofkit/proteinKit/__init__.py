from proteinClass.atom import Atom


